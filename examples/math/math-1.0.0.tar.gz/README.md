# Math

This is a project created using the `nikl init` command. It serves as a template for creating new projects with the Nikl.

## Getting Started
To get started, you can modify the `src/math.nk` file to add your own code.
You can also add any additional files or directories as needed.
